% The MATLAB source code of IDE-EDA is developed in MATLAB R2019b with 64 bits. 
% Please run this code on MATLAB2019b or later with 64 bits. 
% Please cite this article as: Yintong Li, Tong Han, Shangqin Tang,Changqiang Huang, Huan Zhou, Yuan Wang, 
% An Improved Differential Evolution by Hybridizing with Estimation-of-Distribution Algorithm, 
% Information Sciences, https://doi.org/10.1016/j.ins.2022.11.029.
% Corresponding author:Yintong Li. E-mail address: yintongli0007@163.com.
close all
clear
clc
format long
%  mex cec17_func.cpp -DWINDOWS
fobj=str2func('cec17_func');
F_NUM=30;
Fmin=100*(1:30);
dim=[10,30,50];
FEsmax=10000*dim;
lb=-100;
ub=100;
iter=51;
for i=1:size(dim,2)%Number of dim
    SearchAgents_no=ceil(75*dim(i)^(2/3)); % Number of search agents
    % --------------------------end------------------------------------------
    for func_num=1:30
        if func_num==2
            disp('����������F2 have been deleted����������');
            continue;
        else
            disp(['����������The IDE_EDA is optimizing, dim:',num2str(dim(i)),'����������']);
        end
        for repeat=1:iter
            [Best_score,Best_pos,Convergence]=IDE_EDA(SearchAgents_no,FEsmax(i),lb,ub,dim(i),fobj,func_num);
            Best_fitness=Best_score-Fmin(func_num);
            display(['The best  score of F',num2str(func_num),' is : ',num2str(Best_fitness)]);
        end
    end
end



